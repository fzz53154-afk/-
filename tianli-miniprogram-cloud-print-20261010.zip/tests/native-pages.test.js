const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
function loadPage(name, overrides = {}) {
  const filename = path.resolve(__dirname, '../miniprogram/pages', name, name + '.js');
  const localRequire = createRequire(filename);
  let page;
  const dialogs = [];
  const context = {
    require: id => overrides.modules && id in overrides.modules ? overrides.modules[id] : localRequire(id),
    Page: definition => { page = definition; page.data = structuredClone(definition.data); page.setData = patch => Object.assign(page.data, patch); },
    getApp: overrides.getApp,
    wx: { showModal: options => dialogs.push(options), showToast: options => dialogs.push(options), getStorageSync: () => '', ...overrides.wx }
  };
  vm.runInNewContext(fs.readFileSync(filename, 'utf8'), context);
  return { page, dialogs };
}
test('未配置支付后端时绝不调用支付或修改会员余额', async () => {
  let paid = false;
  const { page, dialogs } = loadPage('wallet', { wx: { requestPayment: () => { paid = true; } } });
  await page.recharge();
  assert.equal(paid, false);
  assert.equal(page.data.balance, '—');
  assert.match(dialogs[0].content, /暂不收款/);
});
test('支付客户端回调成功而服务端仍待确认时，不把充值金额计入余额', async () => {
  const calls = [];
  const api = { request: async endpoint => {
    calls.push(endpoint);
    if (endpoint === '/recharges') return { orderId: 'recharge-1', payment: { timeStamp: '1', nonceStr: 'n', package: 'prepay_id=p', signType: 'RSA', paySign: 's' } };
    if (endpoint === '/recharges/recharge-1') return { status: 'pending' };
    if (endpoint === '/member/wallet') return { balance: 1000, records: [] };
    throw new Error('unexpected endpoint');
  } };
  const { page, dialogs } = loadPage('wallet', {
    modules: { '../../config': { apiBaseUrl: 'https://example.test' }, '../../utils/api': api },
    wx: { getStorageSync: () => 'token', requestPayment: options => options.success({}) }
  });
  Object.assign(page.data, { agreed: true, loggedIn: true, selected: 20000 });
  await page.recharge();
  assert.equal(page.data.balance, '10.00');
  assert.equal(dialogs.at(-1).title, '到账确认中');
  assert.deepEqual(calls, ['/recharges', '/recharges/recharge-1', '/member/wallet']);
  assert.equal(page.data.busy, false);
});
test('未开通线上自提时保留购物袋，不能显示订单成功', async () => {
  const { page, dialogs } = loadPage('products');
  Object.assign(page.data, { pickupName: '李小姐', pickupPhone: '18659384298', cart: { count: 1, total: '18.00', items: [{ id: 'croissant', quantity: 1 }] } });
  await page.submitPickup();
  assert.match(dialogs[0].content, /未生成订单/);
  assert.equal(page.data.cart.count, 1);
});
test('自提订单提交失败时保留购物袋以便重试', async () => {
  const { page, dialogs } = loadPage('products', {
    modules: { '../../utils/orders': { configured: true, submit: async () => { throw new Error('网络连接失败'); } } },
    wx: { getStorageSync: () => 'token' }
  });
  Object.assign(page.data, { pickupName: '李小姐', pickupPhone: '18659384298', cart: { count: 1, total: '18.00', items: [{ id: 'croissant', quantity: 1 }] } });
  await page.submitPickup();
  assert.equal(page.data.cart.count, 1);
  assert.equal(page.data.busy, false);
  assert.equal(dialogs[0].title, '订单提示');
});
