const test = require('node:test');
const assert = require('node:assert/strict');
const { submit, publicOrder } = require('../cloudfunctions/orderService/service');
const { processJob } = require('../cloudfunctions/printOrders/worker');
const { receipt } = require('../cloudfunctions/printOrders/receipt');
const { createPrinter } = require('../cloudfunctions/printOrders/feie');
const { createHash } = require('node:crypto');
function database() {
  const tables = { settings: { orders: { enabled: true, printOn: 'submitted' } }, products: { croissant: { name: '原味黄油可颂', price: 1800, stock: 10, sellable: true } }, orders: {}, printJobs: {} };
  let queue = Promise.resolve();
  const repo = {
    tables,
    transaction(callback) {
      const result = queue.then(async () => {
        const copy = structuredClone(tables);
        const tx = {
          get: async (collection, id) => copy[collection][id] ? { _id: id, ...copy[collection][id] } : null,
          set: async (collection, id, data) => { copy[collection][id] = data; },
          update: async (collection, id, data) => Object.assign(copy[collection][id], data)
        };
        const value = await callback(tx);
        Object.assign(tables, copy);
        return value;
      });
      queue = result.catch(() => {});
      return result;
    },
    claim(id, now, stale) {
      return this.transaction(async tx => {
        const job = await tx.get('printJobs', id);
        if (job.state === 'accepted') return job;
        if (job.state === 'processing' && job.updatedAt < now - stale) {
          await tx.update('printJobs', id, { state: 'review', reason: 'worker_interrupted', updatedAt: now }); return null;
        }
        if (!['queued', 'retry'].includes(job.state) || job.nextAt > now) return null;
        await tx.update('printJobs', id, { state: 'processing', updatedAt: now }); return job;
      });
    },
    order: async id => ({ _id: id, ...tables.orders[id] }),
    update(id, data) { return this.transaction(tx => tx.update('printJobs', id, data)); }
  };
  return repo;
}
const payload = { requestId: 'request_1234567890', storeId: 'tianli-fuding', fulfillment: 'pickup', contact: { name: '林女士', phone: '18659384298' }, items: [{ productId: 'croissant', quantity: 2, price: 1 }], total: 1 };
test('服务端定价，订单和打印任务原子保存；并发重复提交只扣一次库存', async () => {
  const repo = database();
  const [first, second] = await Promise.all([submit(repo, 'buyer', payload, 1000), submit(repo, 'buyer', payload, 1000)]);
  assert.deepEqual(first, second);
  assert.equal(Object.keys(repo.tables.orders).length, 1);
  assert.equal(Object.keys(repo.tables.printJobs).length, 1);
  assert.equal(repo.tables.products.croissant.stock, 8);
  assert.equal(repo.tables.orders[first.orderId].total, 3600);
  await assert.rejects(submit(repo, 'buyer', { ...payload, items: [{ productId: 'croissant', quantity: 3 }] }), /上次订单/);
});
test('库存不足不生成订单或打印任务；不同微信用户的相同请求 ID 独立', async () => {
  const repo = database();
  await assert.rejects(submit(repo, 'buyer', { ...payload, items: [{ productId: 'croissant', quantity: 11 }] }), /售罄/);
  assert.equal(repo.tables.products.croissant.stock, 10);
  assert.deepEqual(repo.tables.orders, {});
  assert.deepEqual(repo.tables.printJobs, {});
  const a = await submit(repo, 'buyer', payload);
  const b = await submit(repo, 'other', payload);
  assert.notEqual(a.orderId, b.orderId);
});
test('关闭下单、支付后打印、非法手机号和打印指令注入均拒绝', async () => {
  const repo = database();
  repo.tables.settings.orders.enabled = false;
  await assert.rejects(submit(repo, 'buyer', payload), /未开放/);
  repo.tables.settings.orders.enabled = true;
  repo.tables.settings.orders.printOn = 'paid';
  await assert.rejects(submit(repo, 'buyer', payload), /支付后打印/);
  await assert.rejects(submit(repo, '', payload), /微信/);
  for (const contact of [{ name: '林<BR>', phone: '18659384298' }, { name: '林女士', phone: '123' }]) {
    await assert.rejects(submit(repo, 'buyer', { ...payload, contact }), /手机号/);
  }
});
test('并发打印只发送一次；接收不等于出纸，查询完成才标记已打印', async () => {
  const repo = database();
  const { orderId } = await submit(repo, 'buyer', payload, 1000);
  let sends = 0;
  const printer = { configured: true, send: async () => { sends++; return { accepted: true, taskId: 'cloud-task-1' }; }, completed: async () => false };
  await Promise.all([processJob(repo, printer, orderId, 1000), processJob(repo, printer, orderId, 1000)]);
  assert.equal(sends, 1);
  assert.equal(repo.tables.printJobs[orderId].state, 'accepted');
  await processJob(repo, printer, orderId, 2000);
  assert.equal(repo.tables.printJobs[orderId].state, 'accepted');
  printer.completed = async () => true;
  await processJob(repo, printer, orderId, 3000);
  assert.equal(repo.tables.printJobs[orderId].state, 'printed');
  assert.equal(sends, 1);
  assert.equal(publicOrder({ _id: orderId, ...repo.tables.orders[orderId] }, repo.tables.printJobs[orderId]).openid, undefined);
});
test('打印请求超时转人工核查，定时任务不能自动重复发送', async () => {
  const repo = database(); const { orderId } = await submit(repo, 'buyer', payload, 1000);
  let sends = 0;
  const printer = { configured: true, send: async () => { sends++; throw new Error('timeout'); } };
  await processJob(repo, printer, orderId, 1000);
  await processJob(repo, printer, orderId, 999999);
  assert.equal(repo.tables.printJobs[orderId].state, 'review'); assert.equal(sends, 1);
});
test('明确拒绝可重试，最多五次；未配置打印机保持任务不丢失', async () => {
  const repo = database(); const { orderId } = await submit(repo, 'buyer', payload, 1000);
  await processJob(repo, { configured: false }, orderId, 1000);
  assert.equal(repo.tables.printJobs[orderId].state, 'retry');
  assert.equal(repo.tables.printJobs[orderId].attempts, 0);
  const printer = { configured: true, send: async () => ({ accepted: false }) };
  for (let n = 0; n < 5; n++) await processJob(repo, printer, orderId, 1000000 * (n + 1));
  assert.equal(repo.tables.printJobs[orderId].state, 'failed');
  assert.equal(repo.tables.printJobs[orderId].attempts, 5);
});
test('打印进程中断的过期任务转人工核查，不假定未发送', async () => {
  const repo = database(); const { orderId } = await submit(repo, 'buyer', payload, 1000);
  repo.tables.printJobs[orderId].state = 'processing';
  await processJob(repo, { configured: true, send: () => assert.fail('不应重发') }, orderId, 70000);
  assert.equal(repo.tables.printJobs[orderId].state, 'review');
});
test('小票包含商品、数量、总价、取货人及尚未收款，不执行外来打印标签', async () => {
  const repo = database(); const { orderId } = await submit(repo, 'buyer', payload, 1000);
  const text = receipt(repo.tables.orders[orderId]);
  for (const expected of ['原味黄油可颂', '× 2', '¥36.00', '林女士', '18659384298', '尚未收款']) assert.ok(text.includes(expected));
  repo.tables.orders[orderId].contact.name = '<CUT>\n';
  assert.ok(!receipt(repo.tables.orders[orderId]).includes('<CUT>'));
});
test('飞鹅请求使用签名并保留任务号；非成功响应不能宣称打印完成', async () => {
  const env = { FEIE_USER: 'test-user', FEIE_UKEY: 'test-key', FEIE_SN: 'test-printer' };
  const printer = createPrinter(env, async (url, options) => {
    assert.equal(url, 'https://api.feieyun.cn/Api/Open/');
    const body = options.body;
    assert.equal(body.get('sig'), createHash('sha1').update(env.FEIE_USER + env.FEIE_UKEY + body.get('stime')).digest('hex'));
    if (body.get('apiname') === 'Open_printMsg') return { ok: true, json: async () => ({ ret: 0, data: 'task-1' }) };
    return { ok: true, json: async () => ({ ret: 0, data: true }) };
  });
  assert.deepEqual(await printer.send('test'), { accepted: true, taskId: 'task-1' });
  assert.equal(await printer.completed('task-1'), true);
  await assert.rejects(createPrinter(env, async () => ({ ok: false })).send('test'), /uncertain/);
});
