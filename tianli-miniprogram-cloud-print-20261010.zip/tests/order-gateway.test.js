const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
function gateway(openid, action, staff = '') {
  const queries = [];
  const db = { collection: name => ({
    where: filter => { queries.push(filter); return { orderBy: () => ({ limit: () => ({ get: async () => ({ data: [{ _id: 'saved-1', openid: 'buyer', orderNo: 'TL1' }] }) }) }) }; },
    doc: () => ({ get: async () => ({ data: { state: 'queued' } }) })
  }) };
  const cloud = { init() {}, database: () => db, getWXContext: () => ({ OPENID: openid }), callFunction: async () => { throw new Error('printer unreachable'); } };
  const context = { exports: {}, process: { env: { STAFF_OPENIDS: staff } }, require: name => name === 'wx-server-sdk' ? cloud : {
    submit: async (_, identity) => { assert.equal(identity, openid); return { orderId: 'saved-1' }; },
    publicOrder: (order, job) => ({ orderId: order._id, printState: job.state })
  } };
  vm.runInNewContext(fs.readFileSync(require.resolve('../cloudfunctions/orderService/index'), 'utf8'), context);
  return { result: context.exports.main({ action, order: {} }), queries };
}
test('云端验证身份；顾客只能查询本人，未授权员工不能查询门店订单', async () => {
  assert.equal((await gateway('', 'list').result).ok, false);
  const own = gateway('buyer', 'list');
  assert.equal((await own.result).ok, true);
  assert.equal(JSON.stringify(own.queries), JSON.stringify([{ openid: 'buyer' }]));
  const other = gateway('buyer', 'staffList', 'owner');
  assert.equal((await other.result).ok, false);
  assert.equal(other.queries.length, 0);
  const staff = gateway('owner', 'staffList', 'owner');
  assert.equal((await staff.result).isStaff, true);
  assert.equal(JSON.stringify(staff.queries), JSON.stringify([{ storeId: 'tianli-fuding' }]));
});
test('保存订单后打印机唤起失败，也必须返回已保存的订单号', async () => {
  const result = await gateway('buyer', 'submit').result;
  assert.equal(result.ok, true);
  assert.equal(result.orderId, 'saved-1');
});
