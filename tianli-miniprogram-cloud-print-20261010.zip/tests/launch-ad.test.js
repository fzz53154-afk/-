const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const { createRequire } = require('node:module');
function home(app = { globalData: { launchAdSeen: false } }) {
  const filename = path.resolve(__dirname, '../miniprogram/pages/home/home.js');
  let page, callback, time = 0;
  const calls = [];
  vm.runInNewContext(fs.readFileSync(filename, 'utf8'), {
    require: createRequire(filename),
    Page(value) { page = value; page.data = structuredClone(value.data); page.setData = patch => Object.assign(page.data, patch); },
    getApp: () => app,
    Date: { now: () => time },
    setInterval(cb) { callback = cb; return 1; },
    clearInterval() { callback = null; },
    wx: { hideTabBar: () => calls.push('hide'), showTabBar: () => calls.push('show'), switchTab: value => calls.push(value.url) }
  });
  return { page, app, calls, advance(ms) { time += ms; if (callback) callback(); } };
}
test('开屏3秒自动关闭，恢复底部导航，不会在同次启动重复显示', () => {
  const screen = home(); screen.page.onLoad();
  assert.equal(screen.page.data.showLaunchAd, true);
  screen.advance(1100);
  assert.equal(screen.page.data.adSeconds, 2);
  screen.advance(1900);
  assert.equal(screen.page.data.showLaunchAd, false);
  assert.deepEqual(screen.calls, ['hide', 'show']);
  const next = home(screen.app); next.page.onLoad();
  assert.equal(next.page.data.showLaunchAd, false);
});
test('立即跳过与页面隐藏会清理计时器并恢复导航', () => {
  const screen = home(); screen.page.onLoad(); screen.page.skipLaunchAd(); screen.advance(5000);
  assert.equal(screen.page.data.showLaunchAd, false);
  assert.deepEqual(screen.calls, ['hide', 'show']);
  const hidden = home(); hidden.page.onLoad(); hidden.page.onHide();
  assert.equal(hidden.page.adTimer, null);
  assert.equal(hidden.page.data.showLaunchAd, false);
});
test('广告按钮关闭开屏后进入产品页', () => {
  const screen = home(); screen.page.onLoad(); screen.page.launchAdShop();
  assert.equal(screen.page.data.showLaunchAd, false);
  assert.equal(screen.app.globalData.category, '全部');
  assert.equal(screen.calls.at(-1), '/pages/products/products');
});
