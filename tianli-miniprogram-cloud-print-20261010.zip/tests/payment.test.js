const test = require('node:test');
const assert = require('node:assert/strict');
const { validatePayment } = require('../miniprogram/utils/payment');
test('不完整或伪造的支付参数不能发起支付', () => {
  assert.throws(() => validatePayment(null));
  assert.throws(() => validatePayment({ orderId: '1', payment: {} }));
  assert.throws(() => validatePayment({ orderId: '1', payment: { timeStamp: '1', nonceStr: 'nonce', package: 'invalid', signType: 'RSA', paySign: 'sig' } }));
});
test('支付只接受指定签名字段', () => {
  const params = { timeStamp: '1', nonceStr: 'nonce', package: 'prepay_id=123', signType: 'RSA', paySign: 'sig' };
  assert.deepEqual(validatePayment({ orderId: '1', payment: { ...params, unknown: true } }), params);
});
