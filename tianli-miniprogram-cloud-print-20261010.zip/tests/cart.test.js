const test = require('node:test');
const assert = require('node:assert/strict');
const cart = require('../miniprogram/utils/cart');
test('购物袋仅保留有效产品与整数数量，限制数量', () => {
  assert.deepEqual(cart.normalize({ croissant: 1000, sourdough: -1, chocolate: 1.5, unknown: 2 }), { croissant: 99 });
  assert.deepEqual(cart.normalize(null), {});
});
test('以分计算合计，移除最后一份后不残留商品', () => {
  const order = cart.summarize({ croissant: 2, sourdough: 1 });
  assert.equal(order.cents, 6800);
  assert.equal(order.count, 3);
  assert.equal(order.total, '68.00');
  assert.deepEqual(cart.change({ croissant: 1 }, 'croissant', -1), {});
  assert.deepEqual(cart.change({}, 'unknown', 1), {});
});
