const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
function client(handler) {
  const storage = {};
  const exports = {};
  const context = { module: { exports }, require: id => id === '../config' ? { cloudEnv: 'test' } : {}, wx: {
    getStorageSync: key => storage[key], setStorageSync: (key, value) => { storage[key] = value; }, removeStorageSync: key => { delete storage[key]; }, cloud: { callFunction: handler }
  }};
  vm.runInNewContext(fs.readFileSync(require.resolve('../miniprogram/utils/orders'), 'utf8'), context);
  return context.module.exports;
}
test('客户端网络超时后复用请求 ID，确认成功才清除待确认订单', async () => {
  const calls = [];
  const api = client(async ({ data }) => {
    calls.push(data.order);
    if (calls.length === 1) throw new Error('timeout');
    return { result: { ok: true, orderId: 'order-1' } };
  });
  const payload = { items: [{ productId: 'croissant', quantity: 1 }] };
  await assert.rejects(api.submit(payload), /timeout/);
  assert.ok(api.pending());
  await assert.rejects(api.submit({ items: [] }), /上次订单/);
  const order = await api.recover();
  assert.equal(order.orderId, 'order-1');
  assert.equal(calls[0].requestId, calls[1].requestId);
  assert.equal(api.pending(), null);
});
test('服务端明确拒绝释放待确认状态，服务异常则保留状态', async () => {
  let rejected = true;
  const api = client(async () => ({ result: { ok: false, rejected, message: '商品暂不可购买' } }));
  await assert.rejects(api.submit({ items: [] }));
  assert.equal(api.pending(), null);
  rejected = false;
  await assert.rejects(api.submit({ items: [] }));
  assert.ok(api.pending());
});
