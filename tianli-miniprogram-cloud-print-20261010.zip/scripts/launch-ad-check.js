const { chromium } = require('playwright');
const assert = require('node:assert/strict');
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] });
  try {
    for (const width of [320, 390, 480]) {
      const page = await browser.newPage({ viewport: { width, height: 844 } });
      const errors = []; page.on('pageerror', error => errors.push(error.message));
      await page.goto('http://localhost:3000');
      await page.waitForSelector('#launch-ad');
      await page.waitForFunction(() => Array.from(document.querySelectorAll('#launch-ad img')).every(img => img.complete && img.naturalWidth));
      assert.equal(await page.locator('.header').getAttribute('inert'), '');
      await page.screenshot({ path: `test-results/launch-ad-${width}.png` });
      await page.getByRole('button', { name: '跳过开屏广告', exact: true }).click();
      assert.equal(await page.locator('#launch-ad').count(), 0);
      assert.equal(await page.locator('.header').getAttribute('inert'), null);
      await page.reload();
      await page.waitForSelector('.hero');
      assert.equal(await page.locator('#launch-ad').count(), 0);
      await page.evaluate(() => sessionStorage.clear()); await page.reload();
      await page.getByRole('button', { name: '挑选今日新鲜' }).click();
      await page.waitForSelector('.categories');
      assert.equal(await page.locator('#launch-ad').count(), 0);
      await page.evaluate(() => sessionStorage.clear());
      await page.goto('http://localhost:3000/#stores'); await page.waitForSelector('.store-card');
      assert.equal(await page.locator('#launch-ad').count(), 0);
      await page.goto('http://localhost:3000/'); await page.waitForSelector('#launch-ad');
      await page.waitForSelector('#launch-ad', { state: 'detached', timeout: 5000 });
      assert.deepEqual(errors, []);
      console.log(`${width}px: launch ad, skip, automatic close, session frequency, product link and direct-share guard passed.`);
      await page.close();
    }
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
