const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.name === '.git' || entry.name === 'node_modules' || entry.name === 'test-results') continue;
    const filename = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(filename);
    else if (filename.endsWith('.json')) JSON.parse(fs.readFileSync(filename, 'utf8'));
    else if (filename.endsWith('.js')) execFileSync(process.execPath, ['--check', filename], { stdio: 'pipe' });
  }
}
walk(root);
const manifest = require('../miniprogram/app.json');
manifest.pages.forEach(page => ['js', 'wxml', 'wxss'].forEach(ext => {
  if (!fs.existsSync(path.join(root, 'miniprogram', page + '.' + ext))) throw new Error('Missing page: ' + page + '.' + ext);
}));
const catalog = require('../miniprogram/data/catalog');
if (!fs.existsSync(path.join(root, 'miniprogram', catalog.image))) throw new Error('Missing image');
manifest.tabBar.list.forEach(tab => ['iconPath', 'selectedIconPath'].forEach(key => {
  if (!fs.existsSync(path.join(root, 'miniprogram', tab[key]))) throw new Error('Missing tab icon: ' + tab[key]);
}));
catalog.products.forEach(product => {
  if (!fs.existsSync(path.join(root, 'miniprogram/assets', product.id + '.jpg'))) throw new Error('Missing product image: ' + product.id);
});
manifest.pages.forEach(page => {
  const template = fs.readFileSync(path.join(root, 'miniprogram', page + '.wxml'), 'utf8');
  const script = fs.readFileSync(path.join(root, 'miniprogram', page + '.js'), 'utf8');
  for (const binding of template.matchAll(/(?:bind|catch)(?:tap|input|change)="([A-Za-z][A-Za-z0-9]*)"/g)) {
    if (!new RegExp('\\b' + binding[1] + '\\s*\\(').test(script)) throw new Error('Missing event handler: ' + page + '.' + binding[1]);
  }
});
if (new Set(catalog.products.map(p => p.id)).size !== catalog.products.length) throw new Error('Duplicate product ID');
console.log('JavaScript syntax, JSON, page entrypoints and assets verified.');
