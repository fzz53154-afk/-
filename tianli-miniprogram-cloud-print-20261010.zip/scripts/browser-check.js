const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
  const output = path.resolve(__dirname, '../test-results');
  fs.mkdirSync(output, { recursive: true });
  const errors = [];
  try {
    for (const viewport of [{ width: 1440, height: 1000 }, { width: 390, height: 844 }, { width: 320, height: 740 }]) {
      const page = await browser.newPage({ viewport });
      page.on('pageerror', error => errors.push(error.message));
      await page.goto('http://localhost:3000');
      await page.waitForSelector('.hero h1');
      await page.screenshot({ path: path.join(output, `home-${viewport.width}.png`), fullPage: true });
      await page.getByRole('button', { name: '下一张', exact: true }).click();
      assert.equal(await page.locator('#slide-number').textContent(), '02 / 03');
      await page.getByRole('button', { name: '挑选今日面包' }).click();
      await page.waitForSelector('.categories');
      assert.equal(await page.locator('.product').count(), 2);
      await page.getByRole('tab', { name: '全部', exact: true }).click();
      assert.equal(await page.locator('.product').count(), 4);
      await page.getByRole('textbox', { name: '搜索面包' }).fill('酸种');
      assert.equal(await page.locator('.product').count(), 1);
      await page.getByRole('textbox', { name: '搜索面包' }).fill('不存在');
      assert.equal(await page.locator('.product').count(), 0);
      await page.getByRole('textbox', { name: '搜索面包' }).fill('');
      await page.getByRole('button', { name: '添加原味黄油可颂', exact: true }).click();
      assert.equal(await page.locator('#bag-count').textContent(), '1');
      await page.reload();
      await page.waitForSelector('.product');
      assert.equal(await page.locator('#bag-count').textContent(), '1');
      await page.getByRole('button', { name: '打开购物袋' }).click();
      await page.getByRole('button', { name: '增加原味黄油可颂' }).click();
      assert.equal(await page.locator('.cart-total .price').textContent(), '¥36.00');
      await page.getByRole('button', { name: '减少原味黄油可颂' }).click();
      await page.screenshot({ path: path.join(output, `cart-${viewport.width}.png`) });
      await page.locator('#modal').getByRole('button', { name: '到店自提' }).click();
      await page.locator('input[name="name"]').fill('李小姐');
      await page.locator('input[name="phone"]').fill('18659384298');
      await page.getByRole('button', { name: '确认自提信息' }).click();
      assert.match(await page.locator('#modal').textContent(), /未生成订单/);
      await page.getByRole('button', { name: '关闭', exact: true }).click();
      await page.goto('http://localhost:3000/#wallet');
      await page.waitForSelector('.plans');
      await page.getByRole('button', { name: '¥500 赠 ¥30' }).click();
      assert.match(await page.locator('.recharge').textContent(), /¥500/);
      await page.locator('#agree').check();
      await page.screenshot({ path: path.join(output, `wallet-${viewport.width}.png`), fullPage: true });
      await page.getByRole('button', { name: '微信支付充值 · ¥500' }).click();
      assert.match(await page.locator('#modal').textContent(), /暂不收款/);
      await page.getByRole('button', { name: '知道了' }).click();
      await page.goto('http://localhost:3000/#stores');
      await page.waitForSelector('.store-card');
      assert.match(await page.locator('.store-card').textContent(), /福鼎恒大未来城15栋1单元0109/);
      assert.equal(await page.locator('.store-actions a[href^="tel:"]').getAttribute('href'), 'tel:18659384298');
      await page.screenshot({ path: path.join(output, `stores-${viewport.width}.png`), fullPage: true });
      for (const hash of ['home', 'products', 'stores', 'wallet']) {
        await page.goto('http://localhost:3000/#' + hash);
        await page.waitForSelector('#app > *');
        const stats = await page.evaluate(() => ({
          overflow: document.documentElement.scrollWidth > innerWidth,
          broken: Array.from(document.images).filter(img => !img.complete || !img.naturalWidth).length,
          icons: document.querySelectorAll('svg').length
        }));
        assert.equal(stats.overflow, false, `${hash}: horizontal overflow at ${viewport.width}`);
        assert.equal(stats.broken, 0, `${hash}: broken images`);
        assert.ok(stats.icons > 0);
      }
      console.log(`Verified ${viewport.width}px: carousel, search, category, persisted cart, pickup form, recharge guard and store details.`);
      await page.close();
    }
    assert.deepEqual(errors, []);
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
