const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.jpg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml' };
const server = http.createServer((request, response) => {
  let pathname;
  try { pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname); }
  catch { response.writeHead(400); return response.end('Bad request'); }
  if (pathname === '/') pathname = '/preview/index.html';
  const allowed = pathname.startsWith('/preview/') || pathname === '/miniprogram/data/catalog.js' || pathname.startsWith('/miniprogram/assets/');
  const filename = path.resolve(root, '.' + pathname);
  if (!allowed || !filename.startsWith(root + path.sep)) { response.writeHead(404); return response.end('Not found'); }
  fs.readFile(filename, (error, buffer) => {
    if (error) { response.writeHead(404); return response.end('Not found'); }
    response.writeHead(200, { 'Content-Type': mime[path.extname(filename)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    response.end(buffer);
  });
});
const port = Number(process.env.PORT || 3000);
server.on('error', error => { console.error(error.message); process.exit(1); });
server.listen(port, '0.0.0.0', () => console.log(`恬梨预览：http://localhost:${port}`));
