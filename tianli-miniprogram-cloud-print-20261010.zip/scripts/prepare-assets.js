const fs = require('node:fs');
const path = require('node:path');
const sharp = require('sharp');
const lucide = require('lucide');
const target = path.resolve(__dirname, '../miniprogram/assets');
const source = process.argv[2];
const names = { home: 'House', products: 'Croissant', stores: 'MapPin', wallet: 'UserRound' };
async function main() {
  for (const [filename, name] of Object.entries(names)) {
    for (const [suffix, color] of [['', '#a18c77'], ['-active', '#5a341e']]) {
      const nodes = lucide.icons[name].map(([tag, attrs]) => `<${tag} ${Object.entries(attrs).map(([key, value]) => `${key}="${value}"`).join(' ')} />`).join('');
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${nodes}</svg>`;
      await sharp(Buffer.from(svg)).png().toFile(path.join(target, filename + suffix + '.png'));
    }
  }
  if (!source || !fs.existsSync(source)) return;
  const crops = {
    croissant: { left: 540, top: 330, width: 550, height: 550 },
    sourdough: { left: 635, top: 0, width: 590, height: 590 },
    chocolate: { left: 995, top: 420, width: 430, height: 430 },
    raisin: { left: 1020, top: 650, width: 374, height: 374 }
  };
  for (const [name, crop] of Object.entries(crops)) await sharp(source).extract(crop).resize(600, 600).jpeg({ quality: 82 }).toFile(path.join(target, name + '.jpg'));
  console.log('Bakery images and Lucide tab icons prepared.');
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
