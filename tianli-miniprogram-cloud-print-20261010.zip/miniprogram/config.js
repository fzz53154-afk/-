module.exports = {
  // 填入已配置为小程序 request 合法域名的 HTTPS 后端地址。
  apiBaseUrl: '',
  // 微信云开发环境 ID；启用云端订单和云打印后填写。
  cloudEnv: ''
};
