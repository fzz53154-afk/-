function validatePayment(payload) {
  const params = payload && payload.payment;
  if (!payload || !payload.orderId || !params) throw new Error('充值订单信息不完整');
  ['timeStamp', 'nonceStr', 'package', 'signType', 'paySign'].forEach(key => {
    if (typeof params[key] !== 'string' || !params[key]) throw new Error('支付参数不完整');
  });
  if (!params.package.startsWith('prepay_id=') || !['RSA', 'MD5', 'HMAC-SHA256'].includes(params.signType)) throw new Error('支付参数格式错误');
  return { timeStamp: params.timeStamp, nonceStr: params.nonceStr, package: params.package, signType: params.signType, paySign: params.paySign };
}
module.exports = { validatePayment };
