const catalog = require('../data/catalog');
function normalize(raw) {
  const cart = {};
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return cart;
  catalog.products.forEach(product => {
    const quantity = Number(raw[product.id]);
    if (Number.isInteger(quantity) && quantity > 0) cart[product.id] = Math.min(quantity, 99);
  });
  return cart;
}
function summarize(raw) {
  const cart = normalize(raw);
  const items = catalog.products.filter(p => cart[p.id]).map(p => ({ ...p, quantity: cart[p.id], priceText: (p.price / 100).toFixed(2), subtotal: (p.price * cart[p.id] / 100).toFixed(2) }));
  const cents = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  return { items, count: items.reduce((sum, item) => sum + item.quantity, 0), cents, total: (cents / 100).toFixed(2) };
}
function change(raw, id, delta) {
  const cart = normalize(raw);
  if (!catalog.products.some(p => p.id === id) || !Number.isInteger(delta)) return cart;
  const quantity = Math.max(0, Math.min(99, (cart[id] || 0) + delta));
  if (quantity) cart[id] = quantity;
  else delete cart[id];
  return cart;
}
module.exports = { normalize, summarize, change };
