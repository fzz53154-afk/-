const config = require('../config');
function request(path, method = 'GET', data) {
  return new Promise((resolve, reject) => {
    if (!config.apiBaseUrl.startsWith('https://')) return reject(new Error('会员服务尚未开通，请联系门店'));
    const token = wx.getStorageSync('memberToken');
    wx.request({
      url: config.apiBaseUrl.replace(/\/$/, '') + path, method, data,
      header: token ? { Authorization: 'Bearer ' + token } : {},
      success(response) {
        if (response.statusCode >= 200 && response.statusCode < 300) resolve(response.data);
        else {
          if (response.statusCode === 401) wx.removeStorageSync('memberToken');
          reject(new Error(response.statusCode === 401 ? '登录已过期，请重新登录' : '服务暂时不可用，请稍后重试'));
        }
      },
      fail() { reject(new Error('网络连接失败，请稍后重试')); }
    });
  });
}
async function login() {
  const result = await new Promise((resolve, reject) => wx.login({ success: resolve, fail: () => reject(new Error('微信登录失败，请重试')) }));
  if (!result.code) throw new Error('微信登录失败，请重试');
  const session = await request('/auth/wechat', 'POST', { code: result.code });
  if (!session || typeof session.token !== 'string' || !session.token) throw new Error('登录服务返回异常');
  wx.setStorageSync('memberToken', session.token);
  return session;
}
module.exports = { request, login };
