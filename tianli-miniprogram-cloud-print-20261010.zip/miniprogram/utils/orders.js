const config = require('../config');
const api = require('./api');
const pendingKey = 'tianliPendingOrder';
async function call(action, order) {
  if (!config.cloudEnv || !wx.cloud) throw new Error('云端订单尚未开通，请联系门店');
  const { result } = await wx.cloud.callFunction({ name: 'orderService', data: { action, order } });
  if (!result || !result.ok) {
    const error = new Error(result && result.message || '订单确认暂未完成，请稍后查询，勿重复下单');
    error.rejected = !!(result && result.rejected);
    throw error;
  }
  return result;
}
function pending() { return wx.getStorageSync(pendingKey) || null; }
async function submit(payload) {
  if (!config.cloudEnv) {
    if (!wx.getStorageSync('memberToken')) await api.login();
    return api.request('/orders', 'POST', payload);
  }
  let record = pending();
  if (record && JSON.stringify(record.payload) !== JSON.stringify(payload)) throw new Error('上次订单结果待确认，请到“我的订单”确认后再下新单');
  if (!record) {
    record = { payload, requestId: 'pickup_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2) };
    wx.setStorageSync(pendingKey, record);
  }
  let result;
  try { result = await call('submit', { ...record.payload, requestId: record.requestId }); }
  catch (error) { if (error.rejected) wx.removeStorageSync(pendingKey); throw error; }
  if (!result.orderId) throw new Error('订单结果待确认，请勿重复下单');
  wx.removeStorageSync(pendingKey);
  return result;
}
async function recover() {
  const record = pending();
  if (!record) throw new Error('没有待确认的订单');
  return submit(record.payload);
}
module.exports = { submit, recover, pending, list: staff => call(staff ? 'staffList' : 'list'), configured: !!(config.cloudEnv || config.apiBaseUrl), cloudConfigured: !!config.cloudEnv };
