const data = require('../../data/catalog');
Page({
  data: { stores: data.stores, image: data.image },
  navigate(event) {
    const store = data.stores.find(s => s.id === event.currentTarget.dataset.id);
    if (!Number.isFinite(store.latitude) || !Number.isFinite(store.longitude)) return wx.showModal({ title: '门店位置', content: store.address + '。地图定位正在完善，可复制地址后在地图中搜索。', confirmText: '复制地址', success(result) { if (result.confirm) wx.setClipboardData({ data: store.address }); } });
    wx.openLocation({ latitude: store.latitude, longitude: store.longitude, name: store.name, address: store.address, scale: 16, fail() { wx.showToast({ title: '地图暂时无法打开', icon: 'none' }); } });
  },
  call(event) {
    const store = data.stores.find(s => s.id === event.currentTarget.dataset.id);
    if (!store.phone) return wx.showToast({ title: '门店电话尚未填写', icon: 'none' });
    wx.makePhoneCall({ phoneNumber: store.phone, fail() { wx.showToast({ title: '拨号已取消或无法拨号', icon: 'none' }); } });
  },
  copy(event) {
    const store = data.stores.find(s => s.id === event.currentTarget.dataset.id);
    wx.setClipboardData({ data: store.address });
  }
});
