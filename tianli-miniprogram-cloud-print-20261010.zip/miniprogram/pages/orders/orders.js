const orders = require('../../utils/orders');
const catalog = require('../../data/catalog');
const labels = { queued: '等待打印', processing: '正在发送打印任务', accepted: '已发送，等待打印机完成', printed: '已打印', retry: '打印暂不可用，正在重试', failed: '打印失败，请门店处理', review: '打印结果待核查，请勿重复出单' };
Page({
  data: { orders: [], error: '', busy: false, isStaff: false, staffView: false, pending: false },
  onShow() { this.refresh(); this.timer = setInterval(() => this.refresh(), 5000); },
  onHide() { clearInterval(this.timer); },
  onUnload() { clearInterval(this.timer); },
  async refresh() {
    if (this.data.busy) return;
    this.setData({ pending: !!orders.pending() });
    if (!orders.cloudConfigured) { this.setData({ error: '云端订单尚未开通，请联系门店', orders: [] }); return; }
    this.setData({ busy: true });
    try {
      const result = await orders.list(this.data.staffView);
      this.setData({ isStaff: result.isStaff, error: '', orders: result.orders.map(order => ({ ...order, totalText: (order.total / 100).toFixed(2), timeText: new Date(order.createdAt).toLocaleString(), printText: labels[order.printState] || '打印状态待核查', items: order.items.map(item => ({ ...item, priceText: (item.price / 100).toFixed(2) })) })) });
    } catch (error) { this.setData({ error: error.message }); }
    finally { this.setData({ busy: false }); }
  },
  toggleStaff() { if (this.data.busy) return; this.setData({ staffView: !this.data.staffView, orders: [] }); this.refresh(); },
  async recover() {
    if (this.data.busy) return;
    this.setData({ busy: true });
    try {
      const order = await orders.recover();
      getApp().globalData.cart = {};
      wx.setStorageSync('bakeryCart', {});
      wx.showModal({ title: '订单已确认', content: '订单号：' + order.orderNo + '。到店付款，请等待门店确认。', showCancel: false });
    } catch (error) { wx.showModal({ title: '订单提示', content: error.message, showCancel: false }); }
    finally { this.setData({ busy: false }); this.refresh(); }
  },
  callStore() { wx.makePhoneCall({ phoneNumber: catalog.stores[0].phone }); }
});
