const catalog = require('../../data/catalog');
const orders = require('../../utils/orders');
Page({
  data: { categories: catalog.categories, category: '全部', search: '', image: catalog.image, products: [], cart: { items: [], count: 0, total: '0.00' }, cartOpen: false, pickupOpen: false, pickupName: '', pickupPhone: '', store: catalog.stores[0], busy: false },
  onShow() { this.setData({ category: getApp().globalData.category, cart: getApp().getCart() }); this.filter(); },
  selectCategory(event) { const category = event.currentTarget.dataset.category; getApp().globalData.category = category; this.setData({ category }); this.filter(); },
  search(event) { this.setData({ search: event.detail.value }); this.filter(); },
  filter() {
    const query = this.data.search.trim();
    this.setData({ products: catalog.products.filter(p => (this.data.category === '全部' || p.category === this.data.category) && (p.name + p.description).includes(query)).map(p => ({ ...p, image: '/assets/' + p.id + '.jpg', priceText: (p.price / 100).toFixed(2) })) });
  },
  change(event) { this.setData({ cart: getApp().changeCart(event.currentTarget.dataset.id, Number(event.currentTarget.dataset.delta)) }); },
  detail(event) { this.setData({ selectedProduct: this.data.products.find(p => p.id === event.currentTarget.dataset.id) }); },
  openCart() { this.setData({ cartOpen: true }); },
  close() { if (!this.data.busy) this.setData({ cartOpen: false, selectedProduct: null, pickupOpen: false }); },
  stop() {},
  checkout() { if (this.data.cart.count) this.setData({ cartOpen: false, pickupOpen: true }); },
  pickupName(event) { this.setData({ pickupName: event.detail.value }); },
  pickupPhone(event) { this.setData({ pickupPhone: event.detail.value }); },
  callStore() { wx.makePhoneCall({ phoneNumber: catalog.stores[0].phone }); },
  myOrders() { wx.navigateTo({ url: '/pages/orders/orders' }); },
  async submitPickup() {
    if (this.data.busy) return;
    if (!this.data.pickupName.trim() || !/^1[3-9]\d{9}$/.test(this.data.pickupPhone)) return wx.showToast({ title: '请填写姓名和有效手机号', icon: 'none' });
    if (!orders.configured) return wx.showModal({ title: '线上下单暂未开放', content: '购物袋已保留，当前未生成订单，也未扣款。请联系恬梨确认商品及取货时间。', confirmText: '联系门店', success: result => { if (result.confirm) this.callStore(); } });
    this.setData({ busy: true });
    try {
      const order = await orders.submit({ storeId: this.data.store.id, fulfillment: 'pickup', contact: { name: this.data.pickupName.trim(), phone: this.data.pickupPhone }, items: this.data.cart.items.map(p => ({ productId: p.id, quantity: p.quantity })) });
      if (!order || typeof order.orderId !== 'string' || !order.orderId) throw new Error('订单确认失败，请联系门店核实');
      wx.showModal({ title: '自提订单已提交', content: '订单号：' + (order.orderNo || order.orderId) + '。到店付款，取货时间以门店确认为准。', showCancel: false, success: () => { if (orders.cloudConfigured) this.myOrders(); } });
      getApp().globalData.cart = {};
      wx.setStorageSync('bakeryCart', {});
      this.setData({ cart: getApp().getCart(), pickupOpen: false });
    } catch (error) { wx.showModal({ title: '订单提示', content: error.message, showCancel: false }); }
    finally { this.setData({ busy: false }); }
  },
  onShareAppMessage() { return { title: '恬梨 · 挑选今日面包', path: '/pages/products/products' }; }
});
