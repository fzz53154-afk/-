const data = require('../../data/catalog');
Page({
  data: { brand: data.brand, banners: data.banners, image: data.image, launchAd: data.launchAd, showLaunchAd: false, adSeconds: data.launchAd.duration, products: data.products.map(p => ({ ...p, image: '/assets/' + p.id + '.jpg', priceText: (p.price / 100).toFixed(2) })), store: data.stores[0], activeSlide: 0 },
  onLoad() {
    const app = getApp();
    if (!data.launchAd.enabled || app.globalData.launchAdSeen) return;
    app.globalData.launchAdSeen = true;
    this.adDeadline = Date.now() + data.launchAd.duration * 1000;
    this.setData({ showLaunchAd: true, adSeconds: data.launchAd.duration });
    wx.hideTabBar({ animation: false });
    this.adTimer = setInterval(() => {
      const remaining = Math.max(0, Math.ceil((this.adDeadline - Date.now()) / 1000));
      if (!remaining) this.skipLaunchAd();
      else if (remaining !== this.data.adSeconds) this.setData({ adSeconds: remaining });
    }, 200);
  },
  skipLaunchAd() {
    clearInterval(this.adTimer);
    this.adTimer = null;
    if (!this.data.showLaunchAd) return;
    this.setData({ showLaunchAd: false });
    wx.showTabBar({ animation: false });
  },
  launchAdShop() {
    this.skipLaunchAd();
    getApp().globalData.category = data.launchAd.category;
    wx.switchTab({ url: '/pages/products/products' });
  },
  onHide() { this.skipLaunchAd(); },
  onUnload() { this.skipLaunchAd(); },
  slideChange(event) { this.setData({ activeSlide: event.detail.current }); },
  shop(event) {
    getApp().globalData.category = event.currentTarget.dataset.category || '全部';
    wx.switchTab({ url: '/pages/products/products' });
  },
  wallet() { wx.switchTab({ url: '/pages/wallet/wallet' }); },
  stores() { wx.switchTab({ url: '/pages/stores/stores' }); },
  add(event) {
    getApp().changeCart(event.currentTarget.dataset.id, 1);
    wx.showToast({ title: '已加入购物袋', icon: 'success' });
  },
  detail(event) {
    const product = this.data.products.find(p => p.id === event.currentTarget.dataset.id);
    this.setData({ selectedProduct: product });
  },
  close() { this.setData({ selectedProduct: null }); },
  stop() {},
  onShareAppMessage() { return { title: data.brand.name + ' · 每日新鲜出炉', path: '/pages/home/home' }; }
});
