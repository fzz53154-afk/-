const catalog = require('../../data/catalog');
const api = require('../../utils/api');
const config = require('../../config');
const { validatePayment } = require('../../utils/payment');
Page({
  data: { plans: catalog.rechargePlans.map(p => ({ ...p, amountText: p.amount / 100, giftText: p.gift / 100 })), selected: 20000, agreed: false, balance: '—', loggedIn: false, busy: false, records: [], error: '', configured: !!config.apiBaseUrl },
  onShow() {
    this.setData({ loggedIn: !!wx.getStorageSync('memberToken') });
    if (this.data.loggedIn) this.refresh();
  },
  async login() {
    if (this.data.busy) return;
    this.setData({ busy: true, error: '' });
    try { await api.login(); this.setData({ loggedIn: true }); await this.refresh(); }
    catch (error) { wx.showToast({ title: error.message, icon: 'none' }); }
    finally { this.setData({ busy: false }); }
  },
  async refresh() {
    try {
      const account = await api.request('/member/wallet');
      if (!account || !Number.isSafeInteger(account.balance) || account.balance < 0 || !Array.isArray(account.records)) throw new Error('账户信息暂时无法读取');
      this.setData({ balance: (account.balance / 100).toFixed(2), records: account.records.map(r => ({ ...r, amountText: (r.amount / 100).toFixed(2) })), error: '' });
    } catch (error) { this.setData({ error: error.message, balance: '—', loggedIn: !!wx.getStorageSync('memberToken') }); }
  },
  select(event) { if (!this.data.busy) this.setData({ selected: Number(event.currentTarget.dataset.amount) }); },
  myOrders() { wx.navigateTo({ url: '/pages/orders/orders' }); },
  agree(event) { this.setData({ agreed: event.detail.value.includes('agree') }); },
  terms() { wx.showModal({ title: '储值须知', content: '储值规则、赠送金额和退款政策以上线后门店正式协议为准。当前金额方案为示例，会员服务尚未开通时不收款。支付成功后，以服务器确认的余额为准。', showCancel: false }); },
  async recharge() {
    if (this.data.busy) return;
    if (!config.apiBaseUrl) return wx.showModal({ title: '会员充值暂未开放', content: '门店正在准备会员服务，暂不收款。开通后即可使用微信支付充值。', showCancel: false });
    if (!this.data.agreed) return wx.showToast({ title: '请先阅读并同意储值须知', icon: 'none' });
    if (!this.data.loggedIn) return this.login();
    this.setData({ busy: true });
    try {
      const order = await api.request('/recharges', 'POST', { amount: this.data.selected });
      const payment = validatePayment(order);
      await new Promise((resolve, reject) => wx.requestPayment({ ...payment, success: resolve, fail: result => reject(new Error(result.errMsg.includes('cancel') ? '支付已取消' : '支付未完成，请重试')) }));
      // 客户端支付回调不能证明到账，余额只从服务端读取。
      const status = await api.request('/recharges/' + encodeURIComponent(order.orderId));
      await this.refresh();
      wx.showModal({ title: status.status === 'paid' ? '充值已确认' : '到账确认中', content: status.status === 'paid' ? '储值余额已更新，请查看账户余额。' : '支付结果正在核实，请稍后刷新余额。请勿重复支付。', showCancel: false });
    } catch (error) { wx.showModal({ title: '充值提示', content: error.message, showCancel: false }); }
    finally { this.setData({ busy: false }); }
  }
});
