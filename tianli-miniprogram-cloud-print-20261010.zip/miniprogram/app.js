const cart = require('./utils/cart');
App({
  onLaunch() {
    const config = require('./config');
    if (config.cloudEnv && wx.cloud) wx.cloud.init({ env: config.cloudEnv, traceUser: false });
    this.globalData.cart = cart.normalize(wx.getStorageSync('bakeryCart'));
  },
  globalData: { cart: {}, category: '全部', launchAdSeen: false },
  changeCart(id, delta) {
    this.globalData.cart = cart.change(this.globalData.cart, id, delta);
    wx.setStorageSync('bakeryCart', this.globalData.cart);
    return cart.summarize(this.globalData.cart);
  },
  getCart() { return cart.summarize(this.globalData.cart); }
});
