const cloud = require('wx-server-sdk');
const { submit, publicOrder } = require('./service');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
function missing(error) { return error.errCode === -502005 || /document.*(not exist|not found)/i.test(error.errMsg || error.message || ''); }
async function get(source, collection, id) {
  try { const result = await source.collection(collection).doc(id).get(); return result.data || null; }
  catch (error) { if (missing(error)) return null; throw error; }
}
const repo = { transaction: callback => db.runTransaction(transaction => callback({
  get: (collection, id) => get(transaction, collection, id),
  set: (collection, id, data) => transaction.collection(collection).doc(id).set({ data }),
  update: (collection, id, data) => transaction.collection(collection).doc(id).update({ data })
})) };
exports.main = async event => {
  try {
    const openid = cloud.getWXContext().OPENID;
    if (!openid) return { ok: false, message: '请在微信小程序内使用' };
    const isStaff = (process.env.STAFF_OPENIDS || '').split(',').map(s => s.trim()).filter(Boolean).includes(openid);
    if (event.action === 'identity') return { ok: true, openid };
    if (event.action === 'submit') {
      const order = await submit(repo, openid, event.order);
      // 保存订单和任务后立即唤起打印；失败由定时任务补偿，不能让用户误认为下单失败。
      try { await cloud.callFunction({ name: 'printOrders', data: {} }); } catch (_) {}
      return { ok: true, ...order };
    }
    if (event.action === 'list' || event.action === 'staffList') {
      if (event.action === 'staffList' && !isStaff) return { ok: false, message: '仅门店员工可查看门店订单' };
      const result = await db.collection('orders').where(event.action === 'staffList' ? { storeId: 'tianli-fuding' } : { openid }).orderBy('createdAt', 'desc').limit(30).get();
      const orders = await Promise.all(result.data.map(async order => publicOrder(order, await get(db, 'printJobs', order._id))));
      return { ok: true, orders, isStaff };
    }
    return { ok: false, message: '操作无效' };
  } catch (error) {
    // 不输出客户资料或服务端凭据。
    const rejected = error.code === 'ORDER_REJECTED';
    const message = rejected ? error.message : '订单服务暂时不可用，请稍后重试或联系门店';
    return { ok: false, message, rejected };
  }
};
