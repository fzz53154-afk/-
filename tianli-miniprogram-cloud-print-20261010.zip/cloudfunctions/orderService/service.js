const { createHash } = require('node:crypto');
function fail(message) { const error = new Error(message); error.code = 'ORDER_REJECTED'; throw error; }
function normalize(input) {
  if (!input || !/^[a-zA-Z0-9_-]{16,80}$/.test(input.requestId || '')) fail('订单请求无效，请重新确认');
  if (input.storeId !== 'tianli-fuding' || input.fulfillment !== 'pickup') fail('目前仅支持恬梨门店自提');
  const contact = input.contact || {};
  const name = typeof contact.name === 'string' ? contact.name.trim() : '';
  if (!name || name.length > 20 || /[<>\r\n\x00-\x1f]/.test(name) || !/^1[3-9]\d{9}$/.test(contact.phone || '')) fail('请填写姓名和有效手机号');
  if (!Array.isArray(input.items) || !input.items.length || input.items.length > 30) fail('请选择商品');
  const ids = new Set();
  const items = input.items.map(item => {
    if (!item || !/^[a-z0-9_-]{1,64}$/.test(item.productId || '') || ids.has(item.productId) || !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 99) fail('商品数量无效');
    ids.add(item.productId);
    return { productId: item.productId, quantity: item.quantity };
  }).sort((a, b) => a.productId.localeCompare(b.productId));
  return { storeId: input.storeId, fulfillment: 'pickup', contact: { name, phone: contact.phone }, items };
}
const hash = value => createHash('sha256').update(value).digest('hex');
async function submit(repo, openid, input, now = Date.now()) {
  if (!openid) fail('请在微信小程序内下单');
  const payload = normalize(input);
  const id = hash(openid + ':' + input.requestId);
  const fingerprint = hash(JSON.stringify(payload));
  return repo.transaction(async tx => {
    const existing = await tx.get('orders', id);
    if (existing) {
      if (existing.fingerprint !== fingerprint) fail('上次订单仍在确认，请先查看我的订单');
      return { orderId: existing._id, orderNo: existing.orderNo };
    }
    const settings = await tx.get('settings', 'orders');
    if (!settings || !settings.enabled) fail('线上下单暂未开放，请联系门店');
    if (settings.printOn !== 'submitted') fail('支付后打印尚未接入，请联系门店');
    const items = [];
    for (const item of payload.items) {
      const product = await tx.get('products', item.productId);
      if (!product || product.sellable !== true || !Number.isSafeInteger(product.price) || product.price < 1 || !Number.isSafeInteger(product.stock) || product.stock < item.quantity || typeof product.name !== 'string' || !product.name || product.name.length > 40 || /[<>\r\n\x00-\x1f]/.test(product.name)) fail('商品已售罄或暂不可购买，请刷新购物袋');
      items.push({ ...item, name: product.name, price: product.price });
      await tx.update('products', item.productId, { stock: product.stock - item.quantity });
    }
    const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    if (!Number.isSafeInteger(total)) fail('商品价格配置无效，请联系门店');
    const orderNo = 'TL' + now.toString(36).toUpperCase() + id.slice(0, 8).toUpperCase();
    const order = { ...payload, items, total, openid, fingerprint, orderNo, createdAt: now, status: 'submitted', paymentStatus: 'pay_at_store' };
    await tx.set('orders', id, order);
    await tx.set('printJobs', id, { orderId: id, state: 'queued', attempts: 0, nextAt: now, createdAt: now, updatedAt: now });
    return { orderId: id, orderNo };
  });
}
function publicOrder(order, job) {
  const { _id, orderNo, items, total, contact, createdAt, status, paymentStatus } = order;
  return { orderId: _id, orderNo, items, total, contact, createdAt, status, paymentStatus, printState: job ? job.state : 'review' };
}
module.exports = { normalize, submit, publicOrder };
