const cloud = require('wx-server-sdk');
const { createPrinter } = require('./feie');
const { processJob } = require('./worker');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const repo = {
  async claim(id, now, stale) {
    return db.runTransaction(async tx => {
      const ref = tx.collection('printJobs').doc(id);
      const { data: job } = await ref.get();
      if (!job) return null;
      if (job.state === 'accepted') return job;
      if (job.state === 'processing' && job.updatedAt < now - stale) {
        await ref.update({ data: { state: 'review', reason: 'worker_interrupted', updatedAt: now } });
        return null;
      }
      if (!['queued', 'retry'].includes(job.state) || job.nextAt > now) return null;
      await ref.update({ data: { state: 'processing', updatedAt: now } });
      return job;
    });
  },
  async order(id) { const result = await db.collection('orders').doc(id).get(); return result.data; },
  update(id, data) { return db.collection('printJobs').doc(id).update({ data }); }
};
exports.main = async () => {
  // 不使用客户端传入的内容、订单号或打印机号码，只处理已保存的服务端任务。
  const now = Date.now();
  const { data: jobs } = await db.collection('printJobs').where(db.command.or([
    { state: db.command.in(['queued', 'retry']), nextAt: db.command.lte(now) },
    { state: 'processing', updatedAt: db.command.lt(now - 60000) },
    { state: 'accepted' }
  ])).orderBy('updatedAt', 'asc').limit(20).get();
  const printer = createPrinter();
  await Promise.all(jobs.map(async job => {
    try { await processJob(repo, printer, job._id); }
    catch (_) { /* 留存状态；过期 processing 会转人工核查，不盲目重发。 */ }
  }));
  return { scanned: jobs.length };
};
