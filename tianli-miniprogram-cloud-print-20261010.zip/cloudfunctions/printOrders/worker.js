const { receipt } = require('./receipt');
const STALE_MS = 60000;
async function processJob(repo, printer, id, now = Date.now()) {
  const job = await repo.claim(id, now, STALE_MS);
  if (!job) return;
  if (job.state === 'accepted') {
    try {
      const completed = await printer.completed(job.taskId);
      await repo.update(id, { state: completed ? 'printed' : 'accepted', updatedAt: now });
    } catch (_) { await repo.update(id, { updatedAt: now }); /* 仅查询，不重复发送。 */ }
    return;
  }
  if (!printer.configured) {
    await repo.update(id, { state: 'retry', reason: 'printer_not_configured', nextAt: now + 60000, updatedAt: now });
    return;
  }
  const order = await repo.order(job.orderId);
  if (!order) { await repo.update(id, { state: 'review', reason: 'order_missing', updatedAt: now }); return; }
  let result;
  try { result = await printer.send(receipt(order)); }
  catch (_) {
    // 超时可能发生在打印机已收到任务之后。不能自动重发，否则会重复出单。
    await repo.update(id, { state: 'review', reason: 'delivery_uncertain', updatedAt: now });
    return;
  }
  if (result.accepted) {
    await repo.update(id, { state: 'accepted', taskId: result.taskId, reason: '', updatedAt: now });
  } else {
    const attempts = job.attempts + 1;
    await repo.update(id, { state: attempts >= 5 ? 'failed' : 'retry', attempts, reason: 'provider_rejected', nextAt: now + Math.min(300000, 15000 * 2 ** attempts), updatedAt: now });
  }
}
module.exports = { processJob, STALE_MS };
