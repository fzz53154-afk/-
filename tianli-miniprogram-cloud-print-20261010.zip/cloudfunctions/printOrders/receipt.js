function safe(value) { return String(value).replace(/[<>\r\n\x00-\x1f]/g, ' '); }
const money = cents => (cents / 100).toFixed(2);
function receipt(order) {
  const time = new Date(order.createdAt + 8 * 3600000).toISOString().replace('T', ' ').slice(0, 19);
  return '<CB>恬梨 · 面包甜品</CB><BR>到店自提<BR>' +
    '订单：' + safe(order.orderNo) + '<BR>时间：' + time + '<BR>' +
    '-------------------------------<BR>' + order.items.map(item =>
      safe(item.name) + '<BR>  ¥' + money(item.price) + ' × ' + item.quantity + ' = ¥' + money(item.price * item.quantity) + '<BR>').join('') +
    '-------------------------------<BR><B>合计：¥' + money(order.total) + '</B><BR>' +
    '支付：到店付款（尚未收款）<BR>取货人：' + safe(order.contact.name) + '<BR>电话：' + safe(order.contact.phone) + '<BR>' +
    '取货时间：以门店确认为准<BR>地址：福鼎恒大未来城<BR>15栋1单元0109<BR>门店电话：18659384298<BR><BR>';
}
module.exports = { receipt };
