const { createHash } = require('node:crypto');
// 飞鹅云开放接口；打印机应先在商家后台绑定，密钥仅配置在云函数环境。
function createPrinter(env = process.env, request = fetch) {
  const configured = !!(env.FEIE_USER && env.FEIE_UKEY && env.FEIE_SN);
  async function call(apiname, values) {
    const stime = Math.floor(Date.now() / 1000).toString();
    const sig = createHash('sha1').update(env.FEIE_USER + env.FEIE_UKEY + stime).digest('hex');
    const body = new URLSearchParams({ user: env.FEIE_USER, stime, sig, apiname, ...values });
    const response = await request('https://api.feieyun.cn/Api/Open/', { method: 'POST', body, signal: AbortSignal.timeout(8000) });
    if (!response.ok) throw new Error('printer-response-uncertain');
    const result = await response.json();
    if (!Number.isInteger(result.ret)) throw new Error('printer-response-uncertain');
    return result;
  }
  return {
    configured,
    async send(content) {
      const result = await call('Open_printMsg', { sn: env.FEIE_SN, content, times: '1' });
      if (result.ret !== 0) return { accepted: false };
      if (typeof result.data !== 'string' || !result.data) throw new Error('printer-response-uncertain');
      return { accepted: true, taskId: result.data };
    },
    async completed(taskId) {
      const result = await call('Open_queryOrderState', { orderid: taskId });
      return result.ret === 0 && result.data === true;
    }
  };
}
module.exports = { createPrinter };
